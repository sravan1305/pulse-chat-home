import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { loadOnboarding, type OnboardingAnswers, APPLIANCE_LABEL } from "@/lib/onboarding";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Your Pulse dashboard" },
      { name: "description", content: "Personalized energy tips based on your setup." },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const [data, setData] = useState<OnboardingAnswers | null>(null);
  useEffect(() => {
    setData(loadOnboarding());
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-[color:var(--border)] bg-white">
        <div className="mx-auto flex max-w-[720px] items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--brand-navy)] text-[12px] font-bold text-white">
              P
            </div>
            <span className="text-[14px] font-semibold text-[var(--brand-navy)]">Pulse</span>
          </div>
          <Link
            to="/"
            className="text-[14px] font-medium text-[var(--brand-stone)] underline-offset-4 hover:underline"
          >
            Redo setup
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-[720px] px-5 py-8">
        <h1 className="text-[24px] font-semibold text-[var(--brand-navy)]">
          You're all set
        </h1>
        <p className="mt-1 text-[15px] font-medium text-[var(--brand-stone)]">
          Here's what we stored. Recommendations will appear here next.
        </p>

        <section className="mt-6 rounded-[14px] border border-[color:var(--border)] bg-white p-5">
          <h2 className="text-[14px] font-semibold uppercase tracking-wide text-[var(--brand-stone)]">
            Onboarding answers
          </h2>
          {!data ? (
            <p className="mt-3 text-[15px] text-[var(--brand-navy)]">
              No answers yet —{" "}
              <Link to="/" className="font-semibold underline">
                start setup
              </Link>
              .
            </p>
          ) : (
            <div className="mt-4 space-y-4 text-[15px] text-[var(--brand-navy)]">
              <div>
                <div className="font-semibold">Appliances</div>
                {data.appliances.length === 0 ? (
                  <div className="text-[var(--brand-stone)]">None</div>
                ) : (
                  <ul className="mt-1 list-disc pl-5">
                    {data.appliances.map((a) => (
                      <li key={a.type}>
                        {APPLIANCE_LABEL[a.type]} — {a.smart}, {a.frequency.replace("_", " ")}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <Row label="Overnight" value={data.overnight_preference ?? "—"} />
              <Row
                label="Deadlines"
                value={
                  data.deadlines.length === 0
                    ? "—"
                    : data.deadlines.map((d) => `${d.type} @ ${d.time}`).join(", ")
                }
              />
              <Row label="Priority" value={data.priority ?? "—"} />
              <Row label="Notifications" value={data.notification_preference ?? "—"} />

              <details className="mt-4">
                <summary className="cursor-pointer text-[13px] font-semibold text-[var(--brand-stone)]">
                  Raw JSON
                </summary>
                <pre className="mt-2 overflow-x-auto rounded-[10px] bg-[color:var(--muted)] p-3 text-[12px] text-[var(--brand-navy)]">
                  {JSON.stringify(data, null, 2)}
                </pre>
              </details>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="font-semibold">{label}</div>
      <div className="text-[var(--brand-stone)]">{String(value)}</div>
    </div>
  );
}
